﻿namespace WebBulawanClientAPI.Models
{
    public class RoomType
    {
        public int RoomTypeId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}