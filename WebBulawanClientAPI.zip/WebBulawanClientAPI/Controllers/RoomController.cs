﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebBulawanClientAPI.Models;

namespace WebBulawanClientAPI.Controllers.RoomController
{
    [Authorize]
    public class RoomController : Controller
    {
        private readonly APIGateway apiGateway;

        public RoomController(APIGateway apiGateway)
        {
            this.apiGateway = apiGateway;
        }

        // GET: /Room/Index
        public IActionResult Index()
        {
            var rooms = apiGateway.ListRooms();
            return View(rooms);
        }

        // GET: /Room/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Room/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Room room)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.CreateRoom(room);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error creating room: {ex.Message}");
                }
            }
            return View(room);
        }

        // GET: /Room/Detail/5
        public IActionResult Detail(int id)
        {
            var room = apiGateway.GetRoom(id);
            return View(room);
        }

        // GET: /Room/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var room = apiGateway.GetRoom(id);
            return View(room);
        }

        // POST: /Room/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Room room)
        {
            if (id != room.RoomId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.UpdateRoom(room);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error updating room: {ex.Message}");
                }
            }
            return View(room);
        }

        // GET: /Room/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var room = apiGateway.GetRoom(id);
            return View(room);
        }

        // POST: /Room/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                apiGateway.DeleteRoom(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Error deleting room: {ex.Message}");
                var room = apiGateway.GetRoom(id);
                return View("Delete", room);
            }
        }
    }
}
