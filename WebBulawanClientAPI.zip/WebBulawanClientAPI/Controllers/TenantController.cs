﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebBulawanClientAPI.Models;

namespace WebBulawanClientAPI.Controllers.TenantController
{
    [Authorize]
    public class TenantController : Controller
    {
        private readonly APIGateway apiGateway;

        public TenantController(APIGateway apiGateway)
        {
            this.apiGateway = apiGateway;
        }

        // GET: /Tenant/Index
        public IActionResult Index()
        {
            var tenants = apiGateway.ListTenants();
            return View(tenants);
        }

        // GET: /Tenant/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Tenant/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Tenant tenant)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.CreateTenant(tenant);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error creating tenant: {ex.Message}");
                }
            }
            return View(tenant);
        }

        // GET: /Tenant/Detail/5
        public IActionResult Detail(int id)
        {
            var tenant = apiGateway.GetTenant(id);
            return View(tenant);
        }

        // GET: /Tenant/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var tenant = apiGateway.GetTenant(id);
            return View(tenant);
        }

        // POST: /Tenant/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Tenant tenant)
        {
            if (id != tenant.TenantId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.UpdateTenant(tenant);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error updating tenant: {ex.Message}");
                }
            }
            return View(tenant);
        }

        // GET: /Tenant/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var tenant = apiGateway.GetTenant(id);
            return View(tenant);
        }

        // POST: /Tenant/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                apiGateway.DeleteTenant(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Error deleting tenant: {ex.Message}");
                var tenant = apiGateway.GetTenant(id);
                return View("Delete", tenant);
            }
        }
    }
}
