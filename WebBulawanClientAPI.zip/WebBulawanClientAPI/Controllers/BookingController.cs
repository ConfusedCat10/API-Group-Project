﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebBulawanClientAPI.Models;

namespace WebBulawanClientAPI.Controllers.TenantController
{
    [Authorize]
    public class BookingController : Controller
    {
        private readonly APIGateway apiGateway;

        public BookingController(APIGateway apiGateway)
        {
            this.apiGateway = apiGateway;
        }


        // GET: /Booking/Index
        
        public IActionResult Index()
        {
            var bookings = apiGateway.ListBookings();
            return View(bookings);
        }

        // GET: /Booking/Create
        
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Booking/Create
        
        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Create(Booking booking)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.CreateBooking(booking);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error creating booking: {ex.Message}");
                }
            }
            return View(booking);
        }

        // GET: /Booking/Detail/5
        
        public IActionResult Detail(int id)
        {
            var booking = apiGateway.GetBooking(id);
            return View(booking);
        }

        // GET: /Booking/Edit/5
        [HttpGet]
       
        public IActionResult Edit(int id)
        {
            var booking = apiGateway.GetBooking(id);
            return View(booking);
        }

        // POST: /Booking/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
  
        public IActionResult Edit(int id, Booking booking)
        {
            if (id != booking.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.UpdateBooking(booking);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error updating booking: {ex.Message}");
                }
            }
            return View(booking);
        }

        // GET: /Booking/Delete/5
        [HttpGet]
   
        public IActionResult Delete(int id)
        {
            var booking = apiGateway.GetBooking(id);
            return View(booking);
        }

        // POST: /Booking/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
     
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                apiGateway.DeleteBooking(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Error deleting booking: {ex.Message}");
                var booking = apiGateway.GetBooking(id);
                return View("Delete", booking);
            }
        }
    }
}
