﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebBulawanClientAPI.Models;

namespace WebBulawanClientAPI.Controllers.RoomTypeController
{
    [Authorize]
    public class RoomTypeController : Controller
    {
        private readonly APIGateway apiGateway;

        public RoomTypeController(APIGateway apiGateway)
        {
            this.apiGateway = apiGateway;
        }

        // GET: /RoomType/Index
        public IActionResult Index()
        {
            var roomtype = apiGateway.ListRoomTypes();
            return View(roomtype);
        }

        // GET: /RoomType/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /RoomType/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(RoomType roomtype)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.CreateRoomType(roomtype);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error creating tenant: {ex.Message}");
                }
            }
            return View(roomtype);
        }

        // GET: /RoomType/Detail/5
        public IActionResult Detail(int id)
        {
            var roomtype = apiGateway.GetRoomType(id);
            return View(roomtype);
        }

        // GET: /RoomType/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var roomtype = apiGateway.GetRoomType(id);
            return View(roomtype);
        }

        // POST: /RoomType/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, RoomType roomtype)
        {
            if (id != roomtype.RoomTypeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    apiGateway.UpdateRoomType(roomtype);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error updating tenant: {ex.Message}");
                }
            }
            return View(roomtype);
        }

        // GET: /RoomType/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var roomtype = apiGateway.GetRoomType(id);
            return View(roomtype);
        }

        // POST: /RoomType/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                apiGateway.DeleteRoomType(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Error deleting roomtype: {ex.Message}");
                var roomtype = apiGateway.GetRoomType(id);
                return View("Delete", roomtype);
            }
        }
    }
}
