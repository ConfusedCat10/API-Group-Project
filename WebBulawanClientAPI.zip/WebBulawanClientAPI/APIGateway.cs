﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using WebBulawanClientAPI.Models;

namespace WebBulawanClientAPI
{
    public class APIGateway
    {
        private readonly string roomsUrl = "https://qr34mc1n-5135.asse.devtunnels.ms/api/Rooms";
        private readonly string roomTypesUrl = "https://qr34mc1n-5135.asse.devtunnels.ms/api/RoomTypes";
        private readonly string bookingsUrl = "https://qr34mc1n-5135.asse.devtunnels.ms/api/Bookings";
        private readonly string tenantsUrl = "https://qr34mc1n-5135.asse.devtunnels.ms/api/Tenants";

        private readonly HttpClient httpClient = new HttpClient();

        #region Rooms

        public List<Room> ListRooms()
        {
            List<Room> rooms = new List<Room>();
            ProcessHttpGetRequest(roomsUrl, ref rooms);
            return rooms;
        }

        public Room CreateRoom(Room room)
        {
            return ProcessHttpPostRequest<Room>(roomsUrl, room);
        }

        public Room GetRoom(int id)
        {
            return ProcessHttpGetSingleRequest<Room>($"{roomsUrl}/{id}");
        }

        public void UpdateRoom(Room room)
        {
            ProcessHttpPutRequest($"{roomsUrl}/{room.RoomId}", room);
        }

        public void DeleteRoom(int id)
        {
            ProcessHttpDeleteRequest($"{roomsUrl}/{id}");
        }

        #endregion

        #region RoomTypes

        public List<RoomType> ListRoomTypes()
        {
            List<RoomType> roomtypes = new List<RoomType>();
            ProcessHttpGetRequest(roomTypesUrl, ref roomtypes);
            return roomtypes;
        }

        public RoomType CreateRoomType(RoomType roomtypes)
        {
            return ProcessHttpPostRequest<RoomType>(roomTypesUrl, roomtypes);
        }

        public RoomType GetRoomType(int id)
        {
            return ProcessHttpGetSingleRequest<RoomType>($"{roomTypesUrl}/{id}");
        }

        public void UpdateRoomType(RoomType roomtypes)
        {
            ProcessHttpPutRequest($"{roomTypesUrl}/{roomtypes.RoomTypeId}", roomtypes);
        }

        public void DeleteRoomType(int id)
        {
            ProcessHttpDeleteRequest($"{roomTypesUrl}/{id}");
        }

        #endregion

        #region Bookings

        public List<Booking> ListBookings()
        {
            List<Booking> bookings = new List<Booking>();
            ProcessHttpGetRequest(bookingsUrl, ref bookings);
            return bookings;
        }

        public Booking CreateBooking(Booking booking)
        {
            return ProcessHttpPostRequest<Booking>(bookingsUrl, booking);
        }

        public Booking GetBooking(int id)
        {
            return ProcessHttpGetSingleRequest<Booking>($"{bookingsUrl}/{id}");
        }

        public void UpdateBooking(Booking booking)
        {
            ProcessHttpPutRequest($"{bookingsUrl}/{booking.Id}", booking);
        }

        public void DeleteBooking(int id)
        {
            ProcessHttpDeleteRequest($"{bookingsUrl}/{id}");
        }

        #endregion

        #region Tenants

        public List<Tenant> ListTenants()
        {
            List<Tenant> tenants = new List<Tenant>();
            ProcessHttpGetRequest(tenantsUrl, ref tenants);
            return tenants;
        }

        public Tenant CreateTenant(Tenant tenant)
        {
            return ProcessHttpPostRequest<Tenant>(tenantsUrl, tenant);
        }

        public Tenant GetTenant(int id)
        {
            return ProcessHttpGetSingleRequest<Tenant>($"{tenantsUrl}/{id}");
        }

        public void UpdateTenant(Tenant tenant)
        {
            ProcessHttpPutRequest($"{tenantsUrl}/{tenant.TenantId}", tenant);
        }

        public void DeleteTenant(int id)
        {
            ProcessHttpDeleteRequest($"{tenantsUrl}/{id}");
        }

        #endregion

        #region Private Methods

        private void ProcessHttpGetRequest<T>(string apiUrl, ref List<T> dataList)
        {
            try
            {
                HttpResponseMessage response = httpClient.GetAsync(apiUrl).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    dataList = JsonConvert.DeserializeObject<List<T>>(result);
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception($"Error Occurred at the API Endpoint: {result}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error Occurred at the API Endpoint: {ex.Message}");
            }
        }

        private T ProcessHttpGetSingleRequest<T>(string apiUrl)
        {
            try
            {
                HttpResponseMessage response = httpClient.GetAsync(apiUrl).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<T>(result);
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception($"Error Occurred at the API Endpoint: {result}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error Occurred at the API Endpoint: {ex.Message}");
            }
        }

        private T ProcessHttpPostRequest<T>(string apiUrl, T entity)
        {
            try
            {
                string json = JsonConvert.SerializeObject(entity);
                HttpResponseMessage response = httpClient.PostAsync(apiUrl, new StringContent(json, Encoding.UTF8, "application/json")).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<T>(result);
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception($"Error Occurred at the API Endpoint: {result}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error Occurred at the API Endpoint: {ex.Message}");
            }
        }

        private void ProcessHttpPutRequest<T>(string apiUrl, T entity)
        {
            try
            {
                string json = JsonConvert.SerializeObject(entity);
                HttpResponseMessage response = httpClient.PutAsync(apiUrl, new StringContent(json, Encoding.UTF8, "application/json")).Result;
                if (!response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception($"Error Occurred at the API Endpoint: {result}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error Occurred at the API Endpoint: {ex.Message}");
            }
        }

        private void ProcessHttpDeleteRequest(string apiUrl)
        {
            try
            {
                Console.WriteLine($"Sending DELETE request to URL: {apiUrl}"); // Debugging statement
                HttpResponseMessage response = httpClient.DeleteAsync(apiUrl).Result;

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"DELETE request successful. Status Code: {response.StatusCode}"); // Debugging statement
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    Console.WriteLine($"DELETE request failed. Status Code: {response.StatusCode}, Response: {result}"); // Debugging statement
                    throw new Exception($"Error Occurred at the API Endpoint: {result}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception occurred while sending DELETE request: {ex.Message}"); // Debugging statement
                throw new Exception($"Error Occurred at the API Endpoint: {ex.Message}");
            }
        }


        #endregion
    }
}
